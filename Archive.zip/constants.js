module.exports = {
    API_KEY:'RGAPI-5b4f7a92-ff2e-4cd4-ba49-6ad976efbf7a',
    AWS_ACCESS_KEY: 'AKIAWF6LCRCWVKJ62BHJ',
    AWS_SECRET_KEY: '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',
    BUCKET_NAME: 'league-lookup-users'
};