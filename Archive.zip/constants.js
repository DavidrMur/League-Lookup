module.exports = {
    API_KEY:'RGAPI-2cfd04da-ea4f-49bc-bca9-6f8637a2217f',
    AWS_ACCESS_KEY: 'AKIAWF6LCRCWVKJ62BHJ',
    AWS_SECRET_KEY: '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',
    BUCKET_NAME: 'league-lookup-users'
};