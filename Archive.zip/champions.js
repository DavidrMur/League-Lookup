exports.champions = {
    Aatrox: {
        id: 266
    },
    Ahri: {
        id: 103
    },
    Akali: {
        id: 84
},
    Vi : {
        id: 254
    },
    Riven : {
        id: 92
    },
    irelia : {
        id: 39
    },
    Fiora : {
        id: 114
    },
    ezreal : {
        id: 81
    },
    thresh : {
        id: 412
    },
    elise : {
        id: 60
    },
    poppy : {
        id: 78
    },
    ziggs : {
        id: 115
    },
    rammus : {
        id: 33
    },
    braum : {
        id: 201
    },
    zyra : {
        id: 143
    }
}